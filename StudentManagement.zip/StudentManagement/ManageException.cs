﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentmanagesystem
{
    class ManageException :Exception
    {
        public ManageException()
        {
        }

        public ManageException(string message) : base(message)
        {
        }

        public ManageException(string message, Exception innerException) : base(message, innerException)
        {
        }

        
    }
}
