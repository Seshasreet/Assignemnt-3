﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentmanagesystem
{
    class reports
    {
        public static Dictionary<int, reports> reportslist = new Dictionary<int, reports>();
        public Dictionary<int, admission> al = admission.admissionlist;
        public int StudentId;
        float total;
        public string name, Grade;

        public reports(int studentId, string name, float total, string grade)
        {
            StudentId = studentId;
            this.name = name;
            this.total = total;
            Grade = grade;
        }
        public reports() { }

        public void GetReports(int studentId, string name, float total)
        {
            StudentId = studentId;
            this.name = name;
            this.total = total;
            if (this.total >= 80 && this.total <= 100)
                Grade = "A";
            else if (this.total >= 60)
                Grade = "B";
            else if (this.total >= 40)
                Grade = "C";
            else
                Grade = "FAIL";
            reportslist[StudentId] = new reports(StudentId, name, total, Grade);
        }

        public void UpdateAll()
        {
            if (al.Count == 0)
                Console.WriteLine("No Conetnts available");
            else
            {

                foreach (var i in al)
                {
                    try
                    {
                        if (exams.examlist.ContainsKey(i.Key))
                            GetReports(i.Key, i.Value.studentname, exams.examlist[i.Key].total);
                        else
                            throw new ManageException($"Error Student with id {i.Key} hasn't enrolled for exams");
                    }
                    catch (ManageException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        public void Update(int rid)
        {
            try
            {
                if (exams.examlist.ContainsKey(rid))
                    GetReports(rid, al[rid].studentname, exams.examlist[rid].total);
                else
                    throw new ManageException("Student hasn't enrolled for exams");
            }
            catch (ManageException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public void RemoveById(int id)
        {
            try
            {
                if (reportslist.ContainsKey(id))
                {
                    reportslist.Remove(id);
                    Console.WriteLine($"Contents with student id {id} is deleted in portal");
                }

                else
                    throw new ManageException("Student Details Not in portal");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        internal void display()
        {
            if (reportslist.Count() == 0)
                Console.WriteLine("No Contents Available");
            else
            {
                foreach (var i in reportslist)
                    Console.WriteLine(i.Value);
            }
        }
        public override string ToString()
        {
            return $"studentid = {StudentId}  studentname = {name} Total = {total} Grade = {Grade}";
        }
    }
}

