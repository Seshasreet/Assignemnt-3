﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentmanagesystem
{
    public class admission
    {
        public static Dictionary<int, admission> admissionlist = new Dictionary<int, admission>();
        public static int admissionSeries = 101;
        public static int studentSeries = 501;
        public  int admissionid,studentid,Class;
        public string studentname;
        public admission(int admissionid,int studentid,string studentname,int Class)
        {
            admissionid = admissionid;
            studentid = studentid;
            studentname = studentname;
            this.Class = Class;

        }
        public admission()
        {

        }
        public void  GetAdmissions()
        {
            admissionid = admissionSeries++;
            studentid = studentSeries++;
            Console.WriteLine($"enter student name for studentid{studentid}=");
            studentname = Console.ReadLine();
            Console.WriteLine("enter  class{ studentid}=");
            Class = int.Parse(Console.ReadLine());
            admissionlist.Add(studentid, new admission(admissionid, studentid, studentname, Class));

        }
        public void RemovebyId(int id)
        {
            try
            {
                if (admissionlist.ContainsKey(id))
                {
                    Console.WriteLine($"contents with student id{id} is deleted in system");
                    admissionlist.Remove(id);
                }
                else

                    throw new ManageException("student details not in system");
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }
            
        }
        public void display()
        {
            if (admissionlist.Count() == 0)
                Console.WriteLine("no contents available");
            else
            {
                foreach (var i in admissionlist)
                    Console.WriteLine(i.Value);

            }
        }
        public override string ToString()
        {
            return $"admissionid={admissionid} studentid={studentid} studentname={studentname} Class={Class}";
        }
    }
}
