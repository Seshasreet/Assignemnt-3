﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studentmanagesystem
{
    class exams
    {
        public Dictionary<int, admission> a1 = admission.admissionlist;
        public static Dictionary<int, exams> examlist = new Dictionary<int, exams>();
        public int studentid, numofsubjects;
        public float[] marks;
        public  float total;
        public void Getexams(int studentid)
        {
            total = 0;
            studentid = studentid;
            Console.WriteLine($"enter number of subjects held for studentid {studentid}");
            numofsubjects = int.Parse(Console.ReadLine());
            marks = new float[numofsubjects];
            for (int i = 0; i < numofsubjects; i++)
            {
                Console.Write($"Enter marks for subject {i + 1}: ");
                marks[0] = float.Parse(Console.ReadLine());
                total += marks[0];
            }
            examlist[studentid] = new exams(studentid, total);
        }

        public exams()
        {

        }

        public exams(int studentId, float total)
        {
            studentId = studentId;
            this.total = total;
        }

        public void UpdateAll()
        {
            if (a1.Count == 0)
                Console.WriteLine("No Contents Available");
            else
            {
                foreach (var i in a1)

                    Getexams(i.Key);

            }
        }
        public void RemoveById(int id)
        {
            // int flag = 0;
            try
            {
                if (examlist.ContainsKey(id))
                {
                    examlist.Remove(id);
                    Console.WriteLine($"Contents with student id {id} is deleted in portal");
                }
                else
                    throw new ManageException("Student details not in Portal");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        public void display()
        {
            foreach (var i in examlist)
                Console.WriteLine(i.Value);
        }

        public override string ToString()
        {
            return $"studentid = {studentid}  has a total of {total}";
        }

        internal void Update(int rid)
        {
            if (a1.Count == 0)
                Console.WriteLine("No Contents Available");
            else
            {
                if (a1.ContainsKey(rid))
                    Getexams(rid);
                else
                {
                    Console.WriteLine("Student is not in Portal");
                }
            }
        }

    }

    
}
